﻿using EntityProject.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceProject.Contracts;
using ServiceProject.Services;

namespace UniversityProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentService _studentService;

        public StudentController(IStudentService studentService)
        {
            _studentService = studentService;
        }

        [HttpPost("add")]
        public async Task<IActionResult> Add([FromBody] Student_VM data)
        {
            try
            {
                await _studentService.Add(data);
                return Ok();
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.Message);
            }
        }

        [HttpGet("get")]
        public async Task<IActionResult> Get()
        {
            try
            
            {
                var result = await _studentService.Get();
                return Ok(result);
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.Message);
            }
        }

        [HttpGet("get-by-subjectId")]
        public async Task<IActionResult> StudentsBySubjectId([FromQuery] int subjectId)
        {
            try

            {
                var result = await _studentService.StudentsBySubjectId(subjectId);
                return Ok(result);
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.Message);
            }
        }

    }
}
