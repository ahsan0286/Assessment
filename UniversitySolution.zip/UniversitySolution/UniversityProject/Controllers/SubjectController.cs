﻿using EntityProject.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceProject.Contracts;
using ServiceProject.Services;

namespace UniversityProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubjectController : ControllerBase
    {
        private readonly ISubjectService _subjectService;

        public SubjectController(ISubjectService subjectService)
        {
            _subjectService = subjectService;
        }

        [HttpPost("add")]
        public async Task<IActionResult> Add([FromBody] Subject_VM data)
        {
            try
            {
                await _subjectService.Add(data);
                return Ok();
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.Message);
            }
        }

        [HttpGet("get")]
        public async Task<IActionResult> Get()
        {
            try

            {
                var result = await _subjectService.Get();
                return Ok(result);
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.Message);
            }
        }

        [HttpGet("get-by-studentId")]
        public async Task<IActionResult> SubjectsByStudentId([FromQuery] int studentId)
        {
            try

            {
                var result = await _subjectService.SubjectsByStudentId(studentId);
                return Ok(result);
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.Message);
            }
        }

    }
}
