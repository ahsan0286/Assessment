﻿using EntityProject.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceProject.Contracts;
using ServiceProject.Services;

namespace UniversityProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LectureController : ControllerBase
    {
        private readonly ILectureService _lectureService;

        public LectureController(ILectureService lectureService)
        {
            _lectureService = lectureService;
        }

        [HttpPost("add")]
        public async Task<IActionResult> Add([FromBody] Lecture_VM data)
        {
            try
            {
                await _lectureService.Add(data);
                return Ok();
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.Message);
            }
        }

        [HttpGet("get")]
        public async Task<IActionResult> Get()
        {
            try

            {
                var result = await _lectureService.Get();
                return Ok(result);
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.Message);
            }
        }

    }
}
