﻿using EntityProject.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ServiceProject.Contracts;
using ServiceProject.Services;

namespace UniversityProject.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LectureTheaterController : ControllerBase
    {
        private readonly ILectureTheaterService _lectureTheaterService;

        public LectureTheaterController(ILectureTheaterService lectureTheaterService)
        {
            _lectureTheaterService = lectureTheaterService;
        }

        [HttpPost("add")]
        public async Task<IActionResult> Add([FromBody] LectureTheater_VM data)
        {
            try
            {
                await _lectureTheaterService.Add(data);
                return Ok();
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.Message);
            }
        }

        [HttpGet("get")]
        public async Task<IActionResult> Get()
        {
            try

            {
                var result = await _lectureTheaterService.Get();
                return Ok(result);
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.Message);
            }
        }

    }
}
