﻿using EntityProject.ViewModels;
using RepositoryProject.Contracts;
using ServiceProject.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ServiceProject.Services
{
    public class StudentService : IStudentService
    {
        private readonly IStudentRepository _studentRepository;

        public StudentService(IStudentRepository studentRepository)
        {
            _studentRepository = studentRepository;
        }

        public async Task Add(Student_VM data)
        {
            await _studentRepository.Add(data);
        }

        public async Task<List<Student_VM>> Get()
        {
            return await _studentRepository.Get();
        }

        //Task<List<Student_VM>> StudentsBySubjectId(int subjectId)

        public async Task<List<Student_VM>> StudentsBySubjectId(int subjectId)
        {
            return await _studentRepository.StudentsBySubjectId(subjectId);
        }

    }
}
