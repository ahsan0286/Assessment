﻿using EntityProject.ViewModels;
using RepositoryProject.Contracts;
using RepositoryProject.Repositories;
using ServiceProject.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceProject.Services
{
    public class LectureService : ILectureService
    {
        private readonly ILectureRepository _lectureRepository;

        public LectureService(ILectureRepository lectureRepository)
        {
            _lectureRepository = lectureRepository;
        }

        public async Task Add(Lecture_VM data)
        {
            await _lectureRepository.Add(data);
        }

        public async Task<List<Lecture_VM>> Get()
        {
            return await _lectureRepository.Get();
        }

    }
}
