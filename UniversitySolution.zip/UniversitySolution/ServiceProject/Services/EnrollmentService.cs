﻿using EntityProject.ViewModels;
using RepositoryProject.Contracts;
using ServiceProject.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceProject.Services
{
    public class EnrollmentService : IEnrollmentService
    { 
        private readonly IEnrollmentRepository _enrollmentRepository;

        public EnrollmentService(IEnrollmentRepository enrollmentRepository)
        {
            _enrollmentRepository = enrollmentRepository;
        }

        public async Task Add(EnrollmentAdd_VM data)
        {
            await _enrollmentRepository.Add(data);
        }

        public async Task<List<Enrollment_VM>> Get()
        {
            return await _enrollmentRepository.Get();
        }

    }
}
