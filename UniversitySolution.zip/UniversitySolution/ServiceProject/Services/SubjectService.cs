﻿using EntityProject.ViewModels;
using RepositoryProject.Contracts;
using ServiceProject.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceProject.Services
{
    public class SubjectService : ISubjectService
    {
        private readonly ISubjectRepository _subjectRepository;

        public SubjectService(ISubjectRepository subjectRepository)
        {
            _subjectRepository = subjectRepository;
        }

        public async Task Add(Subject_VM data)
        {
            await _subjectRepository.Add(data);
        }

        public async Task<List<Subject_VM>> Get()
        {
            return await _subjectRepository.Get();
        }

        public async Task<List<Subject_VM>> SubjectsByStudentId(int studentId)
        {
            return await _subjectRepository.SubjectsByStudentId(studentId);
        }

    }
}
