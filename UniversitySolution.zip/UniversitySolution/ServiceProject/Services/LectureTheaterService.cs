﻿using EntityProject.ViewModels;
using RepositoryProject.Contracts;
using RepositoryProject.Repositories;
using ServiceProject.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceProject.Services
{
    public class LectureTheaterService : ILectureTheaterService
    {
        private readonly ILectureTheaterRepository _lectureTheaterRepository;

        public LectureTheaterService(ILectureTheaterRepository lectureTheaterRepository)
        {
            _lectureTheaterRepository = lectureTheaterRepository;
        }

        public async Task Add(LectureTheater_VM data)
        {
            await _lectureTheaterRepository.Add(data);
        }

        public async Task<List<LectureTheater_VM>> Get()
        {
            return await _lectureTheaterRepository.Get();
        }

    }
}
