﻿using EntityProject.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceProject.Contracts
{
    public interface ILectureTheaterService
    {
        Task Add(LectureTheater_VM data);
        Task<List<LectureTheater_VM>> Get();
    }
}
