﻿using EntityProject.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceProject.Contracts
{
    public interface ILectureService
    {
        Task Add(Lecture_VM data);
        Task<List<Lecture_VM>> Get();
    }
}
