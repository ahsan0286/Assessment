﻿using EntityProject.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceProject.Contracts
{
    public interface ISubjectService
    {
        Task Add(Subject_VM data);
        Task<List<Subject_VM>> Get();
        Task<List<Subject_VM>> SubjectsByStudentId(int studentId);
    }
}
