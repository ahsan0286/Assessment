﻿using EntityProject.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryProject.Contracts
{
    public interface IStudentRepository
    {
        Task Add(Student_VM data);
        Task<List<Student_VM>> Get();
        Task<List<Student_VM>> StudentsBySubjectId(int subjectId);
    }
}
