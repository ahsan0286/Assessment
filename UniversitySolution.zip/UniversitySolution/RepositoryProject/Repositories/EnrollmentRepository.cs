﻿using EntityProject.Context;
using EntityProject.Entities;
using EntityProject.ViewModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query.Internal;
using RepositoryProject.Contracts;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryProject.Repositories
{
    public class EnrollmentRepository : IEnrollmentRepository
    {
        private readonly ApplicationDbContext _context;

        public EnrollmentRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        private async Task CheckDuplication(Enrollment data)
        {
            var record = await _context.Enrollments.Where(w => w.Id != data.Id
            && w.StudentId == data.StudentId
            && w.LectureId == data.LectureId
            ).FirstOrDefaultAsync();

            if (record != null)
            {
                throw new Exception("Duplicate record");
            }
        }

        private async Task CapacityExceed(EnrollmentAdd_VM data)
        {
            var subjectlectures = await _context.Lectures.Where(w => w.SubjectId == data.SubjectId).ToListAsync();

            var studentsEnrolled = (from lec in subjectlectures
                                    join enr in _context.Enrollments on lec.Id equals enr.LectureId
                                    group enr by new { enr.StudentId } into g
                                    select g.Count()
                             ).FirstOrDefault();

            studentsEnrolled = studentsEnrolled + 1;

            var result = (from lec in subjectlectures
                                          join lt in _context.LectureTheaters on lec.LectureTheaterId equals lt.Id
                                          group lt by new { lt.Id, lt.Capacity } into g
                                          select new EnrollmentCapacity_VM()
                                          {
                                              LectureTheaterId = g.Key.Id,
                                              Capacity = g.Key.Capacity

                                          }).Any(a=> studentsEnrolled > a.Capacity);

            if (result)
            {
                throw new Exception("Capacity Exceeds");
            }
        }

        private async Task SendNotification(EnrollmentAdd_VM data)
        {
            var record = new EnrollmentNotification()
            {
                StudentId = data.StudentId,
                SubjectId = data.SubjectId,
                Message = "Successfully Enrolled"
            };

            await _context.EnrollmentNotifications.AddAsync(record);
            await _context.SaveChangesAsync();

        }

        public async Task Add(EnrollmentAdd_VM data)
        {
            await CapacityExceed(data);

            List<Enrollment> finalList = new List<Enrollment>();

            var subjectLectures = await _context.Lectures.Where(w => w.SubjectId == data.SubjectId).ToListAsync();

            if (subjectLectures != null && subjectLectures.Count > 0)
            {
                foreach (var item in subjectLectures)
                {
                    var record = new Enrollment()
                    {
                        LectureId = item.Id,
                        StudentId = data.StudentId,
                    };

                    await CheckDuplication(record);

                    finalList.Add(record);
                }
                await _context.Enrollments.AddRangeAsync(finalList);
                await _context.SaveChangesAsync();
                await SendNotification(data);
            }
        }

        public async Task<List<Enrollment_VM>> Get()
        {
            var result = new List<Enrollment_VM>();

            if (_context.Enrollments.Count() > 0)
            {
                result = await _context.Enrollments.DefaultIfEmpty().Select(s => new Enrollment_VM()
                {
                    Id = s.Id,
                    StudentId= s.StudentId,
                    LectureId= s.LectureId
                }).ToListAsync();
            }
            return result;
        }

    }
}
