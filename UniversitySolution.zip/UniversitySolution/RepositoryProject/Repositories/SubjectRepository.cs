﻿using EntityProject.Context;
using EntityProject.Entities;
using EntityProject.ViewModels;
using Microsoft.EntityFrameworkCore;
using RepositoryProject.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryProject.Repositories
{
    public class SubjectRepository : ISubjectRepository
    {
        private readonly ApplicationDbContext _context;

        public SubjectRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        private async Task CheckDuplication(Subject_VM data)
        {
            var record = await _context.Subjects.Where(w => w.Id != data.Id && w.FullName == data.FullName).FirstOrDefaultAsync();

            if (record != null)
            {
                throw new Exception("Duplicate record");
            }
        }

        public async Task Add(Subject_VM data)
        {
            await CheckDuplication(data);

            var record = new Subject()
            {
                Id = data.Id,
                FullName = data.FullName
            };

            _context.Subjects.Add(record);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Subject_VM>> Get()
        {
            var result = new List<Subject_VM>();

            if (_context.Subjects.Count() > 0)
            {
                result = await _context.Subjects.DefaultIfEmpty().Select(s => new Subject_VM()
                {
                    Id = s.Id,
                    FullName = s.FullName,
                }).ToListAsync();
            }
            return result;
        }

        public async Task<List<Subject_VM>> SubjectsByStudentId(int studentId)
        {
            var enrollments = await _context.Enrollments.Where(w=> w.StudentId == studentId).ToListAsync();
            var subjects = (from enr in enrollments
                            join lec in _context.Lectures on enr.LectureId equals lec.Id
                            join sub in _context.Subjects on lec.SubjectId equals sub.Id
                            group sub by new { sub.Id, sub.FullName } into g
                            select new Subject_VM()
                            {
                                Id = g.Key.Id, 
                                FullName = g.Key.FullName,
                            }).ToList();

            return subjects;

        }


    }
}
