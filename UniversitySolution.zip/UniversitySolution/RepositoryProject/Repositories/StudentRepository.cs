﻿using EntityProject.Context;
using EntityProject.Entities;
using EntityProject.ViewModels;
using Microsoft.EntityFrameworkCore;
using RepositoryProject.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryProject.Repositories
{
    
    public class StudentRepository : IStudentRepository
    {
        private readonly ApplicationDbContext _context;

        public StudentRepository(ApplicationDbContext context) 
        {
            _context = context;
        }

        private async Task CheckDuplication(Student_VM data)
        {
            var record = await _context.Students.Where(w => w.Id != data.Id && w.FullName == data.FullName).FirstOrDefaultAsync();

            if (record != null)
            {
                throw new Exception("Duplicate record");
            }
        }

        public async Task Add(Student_VM data)
        {
            await CheckDuplication(data);

            var record = new Student()
            {
                Id = data.Id,
                FullName = data.FullName
            };

            _context.Students.Add(record);
            await _context.SaveChangesAsync();

        }

        public async Task<List<Student_VM>> Get()
        {
            var result = new List<Student_VM>();

            if(_context.Students.Count() > 0)
            {
                result = await _context.Students.DefaultIfEmpty().Select(s => new Student_VM()
                {
                    Id = s.Id,
                    FullName = s.FullName,
                }).ToListAsync();
            }
            return result;
        }

        public async Task<List<Student_VM>> StudentsBySubjectId(int subjectId)
        {
            var lectures = await _context.Lectures.Where(w => w.SubjectId == subjectId).ToListAsync();
            var students = (from lec in lectures
                            join enr in _context.Enrollments on lec.Id equals enr.LectureId
                            join st in _context.Students on enr.StudentId equals st.Id
                            where lec.SubjectId == subjectId
                            group st by new { st.Id, st.FullName } into g
                            select new Student_VM()
                            {
                                Id = g.Key.Id,
                                FullName = g.Key.FullName
                            }).ToList();

            return students;
        }


    }
}
