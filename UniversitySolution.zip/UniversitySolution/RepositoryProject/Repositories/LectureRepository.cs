﻿using EntityProject.Context;
using EntityProject.Entities;
using EntityProject.ViewModels;
using Microsoft.EntityFrameworkCore;
using RepositoryProject.Contracts;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryProject.Repositories
{
    public class LectureRepository : ILectureRepository
    {
        private readonly ApplicationDbContext _context;

        public LectureRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        private int GetWeekOfYear(DateTime startDateTime)
        {
            Calendar Calendar = CultureInfo.InvariantCulture.Calendar;
            return Calendar.GetWeekOfYear(startDateTime, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
        }

        private async Task CheckDuplication(Lecture_VM data)
        {
            var record = await _context.Lectures.Where(w => w.Id != data.Id
            && w.SubjectId == data.SubjectId
            && w.StratDateTime == data.StratDateTime
            && w.EndDateTime == data.EndDateTime
            && w.LectureTheaterId == data.LectureTheaterId
            && w.WeekNo == data.WeekNo
            ).FirstOrDefaultAsync();

            if (record != null)
            {
                throw new Exception("Duplicate record");
            }
        }

        private async Task WeeklyHoursExceed(Lecture_VM data)
        {
            var result = await (from lec in _context.Lectures
                                where lec.SubjectId == data.SubjectId
                                && lec.WeekNo == data.WeekNo
                                group lec by new { lec.WeekNo } into g
                                select new EnrollmentCapacity_VM()
                                {
                                    WeekNo = g.Key.WeekNo,
                                    Duration = g.Sum(s => s.Duration)

                                }).AnyAsync(a => (a.Duration + data.Duration) > 10);

            if (result)
            {
                throw new Exception("Weekly Hours Limit Exceeds");
            }

        }

        public async Task Add(Lecture_VM data)
        {
            await CheckDuplication(data);

            data.Duration = data.EndDateTime.Subtract(data.StratDateTime).Hours;
            data.WeekNo = GetWeekOfYear(data.StratDateTime);

            await WeeklyHoursExceed(data);

            var record = new Lecture()
            {
                Id = data.Id,
                SubjectId = data.SubjectId,
                StratDateTime = data.StratDateTime,
                EndDateTime = data.EndDateTime,
                Duration = data.Duration,
                LectureTheaterId = data.LectureTheaterId,
                WeekNo = data.WeekNo
            };

            _context.Lectures.Add(record);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Lecture_VM>> Get()
        {
            var result = new List<Lecture_VM>();

            if (_context.Lectures.Count() > 0)
            {
                result = await _context.Lectures.DefaultIfEmpty().Select(s => new Lecture_VM()
                {
                    Id = s.Id,
                    SubjectId = s.SubjectId,
                    StratDateTime = s.StratDateTime,
                    EndDateTime = s.EndDateTime,
                    Duration = s.Duration,
                    LectureTheaterId = s.LectureTheaterId,
                    WeekNo = s.WeekNo

                }).ToListAsync();
            }
            return result;
        }


    }
}
