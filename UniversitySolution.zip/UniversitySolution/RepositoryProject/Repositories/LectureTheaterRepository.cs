﻿using EntityProject.Context;
using EntityProject.Entities;
using EntityProject.ViewModels;
using Microsoft.EntityFrameworkCore;
using RepositoryProject.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepositoryProject.Repositories
{
    public class LectureTheaterRepository : ILectureTheaterRepository
    {
        private readonly ApplicationDbContext _context;

        public LectureTheaterRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        private async Task CheckDuplication(LectureTheater_VM data)
        {
            var record = await _context.LectureTheaters.Where(w => w.Id != data.Id && w.FullName == data.FullName 
            && w.Capacity == data.Capacity).FirstOrDefaultAsync();

            if (record != null)
            {
                throw new Exception("Duplicate record");
            }
        }

        public async Task Add(LectureTheater_VM data)
        {
            await CheckDuplication(data);

            var record = new LectureTheater()
            {
                Id = data.Id,
                FullName = data.FullName,
                Capacity = data.Capacity
            };

            _context.LectureTheaters.Add(record);
            await _context.SaveChangesAsync();
        }

        public async Task<List<LectureTheater_VM>> Get()
        {
            var result = new List<LectureTheater_VM>();

            if (_context.Subjects.Count() > 0)
            {
                result = await _context.LectureTheaters.DefaultIfEmpty().Select(s => new LectureTheater_VM()
                {
                    Id = s.Id,
                    FullName = s.FullName,
                }).ToListAsync();
            }
            return result;
        }

    }
} 
