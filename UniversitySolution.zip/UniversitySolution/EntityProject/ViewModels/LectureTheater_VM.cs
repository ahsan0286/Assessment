﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityProject.ViewModels
{
    public class LectureTheater_VM
    {
        public int Id { get; set; }
        public string FullName { get; set; }
        public short Capacity { get; set; }
    }
}
