﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityProject.ViewModels
{
    public class Enrollment_VM
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public int LectureId { get; set; }
    }

    public class EnrollmentAdd_VM
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public int SubjectId { get; set; }
        public int LectureId { get; set; }
    }

    public class EnrollmentCapacity_VM
    {
        public int LectureId { get; set; }
        public int WeekNo { get; set; }
        public int LectureTheaterId { get; set; }
        public int Capacity { get; set; }
        public int Duration { get; set; }
    }



}
