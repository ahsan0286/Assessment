﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityProject.ViewModels
{
    public class Lecture_VM
    {
        public int Id { get; set; }
        public int SubjectId { get; set; }
        public DateTime StratDateTime { get; set; }
        public DateTime EndDateTime { get; set; }
        public int Duration { get; set; }
        public int LectureTheaterId { get; set; }
        public int WeekNo { get; set; }
    }
}
